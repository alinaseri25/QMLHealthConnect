#ifndef BACKEND_H
#define BACKEND_H

#include <QObject>
#include <QTimer>
#include <QPointF>
#include <QRandomGenerator>
#include <QDebug>
#include <QDateTime>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QThread>

#ifdef Q_OS_ANDROID
#include <QJniObject>
#include <QCoreApplication>
#include <QtCore/qnativeinterface.h>
#include <QJniEnvironment>
#endif

class Backend : public QObject
{
    Q_OBJECT
public:
    explicit Backend(QObject *parent = nullptr);

public slots:
    void onUpdateRequest(bool height,bool weight,bool bp,bool bg,bool hr,bool spo2);
    void writeHeight(double heightMeters);
    void writeWeight(double weightKg);
    void writeBloodPressure(double systolicMmHg, double diastolicMmHg);
    void writeHeartRate(int bpm);
    void writeBloodGlucose(double glucoseMgDl, int specimenSource = 2,
                           int mealType = 0, int relationToMeal = 0);
    void writeOxygenSaturation(double percentage);

private:
    QList<QPointF> hList,wList;
    QList<QPointF> bpSystolicList;
    QList<QPointF> bpDiastolicList;
    QList<QPointF> heartRateList;
    QList<QPointF> bloodGlucoseList;
    QList<QPointF> oxygenSaturationList;

    void permissionRequest(void);
    bool checkPermissions(void);
    void readHeight(QString startTime,QString endTime);
    void readWeight(QString startTime,QString endTime);
    void readBP(QString startTime,QString endTime);
    void readHR(QString startTime,QString endTime);
    void readBG(QString startTime,QString endTime);
    void readOxygenSaturation(QString startTime, QString endTime);
    static QString isoStringMonthsAgo(int months);

signals:
    void newDataRead(QList<QPointF> hList,
                     QList<QPointF> wList,
                     QList<QPointF> bpSystolicList, QList<QPointF> bpDiastolicList,
                     QList<QPointF> heartRateList,
                     QList<QPointF> bloodGlucoseList,
                     QList<QPointF> oxygenSaturationList);
    void heightWritten(bool success, QString message);
    void weightWritten(bool success, QString message);
    void bloodPressureWritten(bool success, QString message);
    void heartRateWritten(bool success, QString message);
    void bloodGlucoseWritten(bool success, QString message);
    void oxygenSaturationWritten(bool success, QString message);
};

#endif // BACKEND_H
