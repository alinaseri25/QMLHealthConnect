#include "backend.h"

Backend::Backend(QObject *parent)
    : QObject{parent}
{}

void Backend::permissionRequest()
{
#ifdef Q_OS_ANDROID
    // ✅ دریافت Activity (نه Application Context)
    QJniObject activity = QNativeInterface::QAndroidApplication::context();

    if (!activity.isValid()) {
        qDebug() << ("❌ Activity is invalid!");
        return;
    }

    // Init
    QJniObject::callStaticMethod<void>(
        "org/verya/HealthConnectTest/HealthBridge",
        "init",
        "(Landroid/content/Context;)V",
        activity.object()
        );

    qDebug() << ("=== 🔐 Health Connect Test ===\n");

    // Check permissions
    QJniObject result = QJniObject::callStaticObjectMethod(
        "org/verya/HealthConnectTest/HealthBridge",
        "checkPermissions",
        "()Ljava/lang/String;"
        );
    qDebug() << ("🔑 Current: " + result.toString());

    // ✅ Request permissions با پاس دادن Activity
    qDebug() << ("\n🚀 Requesting permissions...");
    result = QJniObject::callStaticObjectMethod(
        "org/verya/HealthConnectTest/HealthBridge",
        "requestPermissions",
        "(Landroid/app/Activity;)Ljava/lang/String;",
        activity.object()
        );

    qDebug() << ("✅ Result: " + result.toString());
    qDebug() << ("\n💡 If dialog appeared, grant permissions then press Read.");

#else
    qDebug() << "Not Android";
#endif
}
